<?php
/**
 * Configuration for: Database Connection
 *
 */
define("DB_HOST", "localhost");
define("DB_NAME", "addressBook");
define("DB_USER", "root");
define("DB_PASS", "");
